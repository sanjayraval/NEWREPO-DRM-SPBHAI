![Typing SVG](https://readme-typing-svg.herokuapp.com/?lines=Welcome+To+Txt+Uploader+Bot+!)

***Welcome to DRM bot made by @nikhil.saini.khe (Instagram)***

**Don't Remove Credit tag**
**Note:** CP DRM SUPPORTED MINIMUM QUALITY 360

## Commands

> /start - Start the Bot.  
> /stop - Stop the Bot.  
> /help - To get help for using this bot.

## Deployment Process 
Watch YouTube Video
https://youtu.be/PYDtSTM6w44?si=noKPl7o4iU9SR_TO

> 1. Fork the Repository
> 2. edit vars.py and fillup API ID and API HASH
> 3. edit readme.md and change button link by your repository link
> 4. Now direct click on button eg. Render, Heroku, Koyeb



## Deploy Via Buttons

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://www.heroku.com/deploy?template=https://github.com/nikhilsainiop/saini-txt-direct)

[![Deploy To Heroku](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?button-url=https://github.com/xpingpongx/Extractor-V3&template=https://github.com/nikhilsainiop/saini-txt-direct)

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy)

[![Deploy to Koyeb](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/deploy?name=saini-txt-direct&repository=nikhilsainiop%2FSaini-txt-direct&branch=main&instance_type=free&instances_min=0)


Bot username
@saini_contact_bot
@saini_file_store_bot


Repo 
https://github.com/nikhilsainiop/saini-txt-direct

https://github.com/cyberseller999/saini-txt-direct
